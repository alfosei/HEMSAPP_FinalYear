document.addEventListener('DOMContentLoaded', () => {
  const socket = new WebSocket('ws://172.20.10.7:81');//NodeMCU IP address

  const toggleButton = document.getElementById('toggleButton');
  const toggleButton2 = document.getElementById('toggleButton2');
  const statusSpan = document.getElementById('status');
  const statusSpan2 = document.getElementById('status2'); // Separate status for Smart Socket 2
  let isToggle2 = false; // Flag to track toggle state for Smart Socket 2

  socket.onopen = () => {
    console.log('WebSocket connection established.');
  };

  socket.onmessage = (event) => {
    const message = event.data;
    console.log('Received message:', message);
    
    const [status1, status2] = message.split(',');
    statusSpan.textContent = `Relay Status: ${status1}`;
    statusSpan2.textContent = `Relay Status: ${isToggle2 ? status2 : 'Unknown'}`;
  };

  socket.onclose = () => {
    console.log('WebSocket connection closed.');
  };

  toggleButton.addEventListener('click', () => {
    if (socket.readyState === WebSocket.OPEN) {
      socket.send('toggle');
      console.log('WebSocket message sent: toggle');
    }
  });

//   toggleButton2.addEventListener('click', () => {
//     isToggle2 = !isToggle2; // Toggle the flag
//     const relayCommand = isToggle2 ? 'toggle2' : 'toggle';
//     sendHttpRequest(relayCommand);
//   });

//   function sendHttpRequest(command) {
//     const raspberryPiUrl = 'http://192.168.137.100:5001/control/' + command; // Replace with the actual IP of your Raspberry Pi
//     fetch(raspberryPiUrl)
//       .then(response => response.text())
//       .then(result => {
//         console.log(result);
//       })
//       .catch(error => {
//         console.error('Error sending HTTP request:', error);
//       });
//   }

});

function goBack() {
  window.history.back();
}
